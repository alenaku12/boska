.. _telethon-utils:

=========
Utilities
=========

These are the utilities that the library has to offer.

.. automodule:: telethon.utils
    :members:
    :undoc-members:
    :show-inheritance:
